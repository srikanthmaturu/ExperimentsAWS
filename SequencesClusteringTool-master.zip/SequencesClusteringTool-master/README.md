# SequencesClusteringTool
A tool that clusters sequences from FASTA file based similarity measures
